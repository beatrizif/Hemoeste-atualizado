<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Registro</title>

   <!-- <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx" crossorigin="anonymous"> -->

</head>
<body>
    <center><div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    <div class="box">
                <form action="<?php echo e(url('register')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <center><h1>Registro do Doador</h1></center>

                    <div class="inputs">
                        <label for="nome">Nome</label>
                        <input type="nome" placeholder="Digite seu nome" id="name" name="name">
                    </div>

                    <div class="inputs">
                        <label for="email">Email</label>
                        <input type="email" placeholder="Digite seu email" id="email" name="email">
                    </div>

                    <div class="inputs">
                        <label for="password">Senha</label>                
                        <input type="password" placeholder="Digite sua senha" id="password" name="password">
                    </div>

                    <div class="inputs">
                        <label for="password">Confirme a senha</label>
                        <input type="password" class="form-control" placeholder="Digite sua senha novamente" id="password_confirmation" name="password_confirmation">
                    </div>

                    <div class="inputs">
                        <label for="">CPF</label>
                        <input type="cpf" name="cpf" placeholder="Digite seu CPF">
                    </div>

                    <div class="inputs">
                        <label for="">SUS</label>
                        <input name="sus" placeholder="Digite seu cartão do SUS">
                    </div>

                    <div class="inputs">
                        <label for="">Tipo sanguíneo</label>
                        <input name="tipo" placeholder="Digite seu tipo sanguíneo">
                    </div>
                        
                            <center><button type="submit" class="btn btn-success btn-sm">Registrar</button></center>
                </form>
    

    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.5/dist/umd/popper.min.js" integrity="sha384-Xe+8cL9oJa6tN/veChSP7q+mnSPaj5Bcu9mPX5F5xIGE0DVittaqT5lorf0EI7Vk" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.min.js" integrity="sha384-ODmDIVzN+pFdexxHEHFBQH3/9/vQ9uori45z4JjnFsRydbmQbmL5t1tQ0culUzyK" crossorigin="anonymous"></script>
    </div></center>
    <style>
        .inputs{
            border-radius: 10px;
            display: block;
            margin: 15px;
        }
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-color: #710C04;
            color: #d3d3d3;
            margin: 0px;
            padding: 0px;
            border: 0px;
        }
        .head{
            background-color: #d3d3d3;
        }
        .img-read{
            padding: 10px;
            height: 100px;
        }
        input{
            height: 30px;
        }
        .box{
            text-align: left;
            font-weight: bold;
            display: block;
            background-color: #d3d3d3;
            color: #710C04;
            border: 50px;
            height: 500px;
            width: 400px;
            border-radius: 14px;
            padding: 15px;
            margin: 50px;
        }
        input{
            border-radius: 7px;
            border: solid 2px #710C04;
        }
        button{
            background-color: #710C04;
            font-weight: bold;
            color: #d3d3d3;
            height: 30px;
            border: solid 1px #710C04;
            border-radius: 7px;
        }
    </style>
</body>
</html><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/auth/register.blade.php ENDPATH**/ ?>