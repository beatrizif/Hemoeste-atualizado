<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hemoeste</title>
</head>
<body>
    <center><div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    
    <h1>Agora você pode acessar o Portal do Hemoeste na sua casa</h1>
    <img class="body" src = "https://imagens.ebc.com.br/h8DvueXOfVYK6DcobKSa9rg-nf8=/1170x700/smart/https://agenciabrasil.ebc.com.br/sites/default/files/thumbnails/image/51246851991_c90daf8bc5_o.jpg?itok=2JJK0KjJ">
    <form action= "<?php echo e(url('/login')); ?>">
        <button>Central do Doador</button></center>
    </form>
</body>
<style>
    body{
        font-family: Arial, Helvetica, sans-serif;
        background-color: #710C04;
        color: #d3d3d3;
        margin: 0px;
        padding: 0px;
        border: 0px;
    }
    .head{
        background-color: #d3d3d3;
    }
    .img-read{
        padding: 10px;
        height: 100px;
    }
    .body{
        border-radius: 15px;
        margin: 15px;
        height: 400px;
    }
    button{
        background-color: #d3d3d3;
        font-weight: bold;
        color: #710C04;
        height: 30px;
        border: solid 1px #d3d3d3;
        border-radius: 7px;
    }
</style>
</html><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/welcome.blade.php ENDPATH**/ ?>