<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-color: #710C04;
            color: #d3d3d3;
            margin: 0px;
            padding: 0px;
            border: 0px;
        }
        .head{
            background-color: #d3d3d3;
        }
        .img-read{
            padding: 10px;
            height: 100px;
        }
        body{
            font-family: Arial, Helvetica, sans-serif;
            background-color: #710C04;
            color: #d3d3d3;
            margin: 0px;
            padding: 0px;
            border: 0px;
        }
        button{
            background-color: #710C04;
            font-weight: bold;
            color: #d3d3d3;
            height: 30px;
            border: solid 1px #710C04;
            border-radius: 7px;
            margin: 7px;
        }
        .box{
            font-weight: bold;
            display: block;
            background-color: #d3d3d3;
            color: #710C04;
            border: 50px;
            height: 250px;
            width: 300px;
            border-radius: 14px;
            padding: 15px;
            margin: 50px;
        }
    </style>
</head>
<body>
    <center><div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    <div class="box">
        <ul>            
            <?php $__empty_1 = true; $__currentLoopData = Auth::user()->notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($notification->type == 'App\Notifications\UpdateProfileNotification'): ?>
                    <li>Você mudou seu nome de <?php echo e($notification->data['old_name']); ?> para <?php echo e($notification->data['new_name']); ?></li>
                    <hr>
                <?php endif; ?>
                <?php if($notification->type == 'App\Notifications\NewDonationNotification'): ?>
                    <li><?php echo e($notification->data['name']); ?> fez uma doação em <?php echo e($notification->data['date']); ?></li>
                    <hr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <h2>Você não possui nenhuma notificação</h2>
            <?php endif; ?>
        </ul>
    </div>
    </form></center>
</body>
</html><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/auth/notifications.blade.php ENDPATH**/ ?>