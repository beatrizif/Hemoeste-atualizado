<h1>Sua solicitação foi registrada, <?php echo e($donation->nome); ?></h1>
<p>
    Obrigado por fazer parte daquelas poucas pessoas que se empenham na campanha de doação de sangue. Você faz a diferença e salva vidas.
</p>
<p>
    A solicitação está prevista para: <?php echo e($donation->data); ?> às <?php echo e($donation->hora); ?>

</p><?php /**PATH D:\Dev\Atividades\Hemoeste\resources\views/mail/solicitacao.blade.php ENDPATH**/ ?>