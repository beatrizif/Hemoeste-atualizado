<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ver</title>
</head>
<body>
    <div class="head">
        <img class="img-read" src="<?php echo e(asset('img-resource/hemoeste.png')); ?>">
    </div>
    <ul> 
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li>
        
            <b><p>ID:</p></b>
                <p><?php echo e($item->id); ?></p>
            <b><p>Nome:</p></b>   
                <p> <?php echo e($item->name); ?></p>
            <b><p>Email:</p></b>  
                <p> <?php echo e($item->email); ?></p>
            <b><p>CPF:</p></b> 
                <p> <?php echo e($item->cpf); ?></p>
            <b><p>Cartão SUS:</p></b> 
                <p> <?php echo e($item->sus); ?></p>
            <b><p>Tipo sanguíneo:</p></b> 
                <p> <?php echo e($item->tipo); ?></p>
        </li>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>

    <form action="<?php echo e(url('/editar')); ?>" method="GET">
        <?php echo csrf_field(); ?>
        <button>Editar perfil</button>
    </form>
</body>
<style>
    body{
        font-family: Arial, Helvetica, sans-serif;
        background-color: #710C04;
        color: #d3d3d3;
        margin: 0px;
        padding: 0px;
        border: 0px;
    }
    .head{
        background-color: #d3d3d3;
    }
    .img-read{
        padding: 10px;
        height: 100px;
    }
    button{
        background-color: #d3d3d3;
        font-weight: bold;
        color: #710C04;
        height: 30px;
        border: solid 1px #d3d3d3;
        border-radius: 7px;
        margin: 15px;
    }
</style>
</html><?php /**PATH C:\Users\20201101110021\Documents\Hemoeste\resources\views/doador/ver.blade.php ENDPATH**/ ?>